import torch

from torch.utils.data import Dataset

from config import SEQ_LEN

# ============================================================
# DATASET
# ============================================================

class TimeSeriesDataset(Dataset):

    def __init__(

        self,

        states,

        controls,

        inputs
    ):

        self.states = states

        self.controls = controls

        self.inputs = inputs

    def __len__(self):

        return len(self.states) - SEQ_LEN

    def __getitem__(self, idx):

        x0 = self.states[idx]

        target = self.states[
            idx : idx + SEQ_LEN
        ]

        u_seq = self.controls[
            idx : idx + SEQ_LEN
        ]

        x_seq = self.inputs[
            idx : idx + SEQ_LEN
        ]

        return (

            torch.tensor(
                x0,
                dtype=torch.float32
            ),

            torch.tensor(
                target,
                dtype=torch.float32
            ),

            torch.tensor(
                u_seq,
                dtype=torch.float32
            ),

            torch.tensor(
                x_seq,
                dtype=torch.float32
            )
        )