from scipy.io import loadmat
import os

# ============================================================
# LOAD DATA
# ============================================================

def load_dataset():

    data_directory = r"B:\Studium\TeamProject\Code"

    train_data = loadmat(
        os.path.join(
            data_directory,
            "Exp_12May_1457_upsamp_filt.mat"
        )
    )

    val_data = loadmat(
        os.path.join(
            data_directory,
            "Exp_12May_1500_upsamp_filt.mat"
        )
    )

    test_data = loadmat(
        os.path.join(
            data_directory,
            "Exp_12May_1503_upsamp_filt.mat"
        )
    )

    return train_data, val_data, test_data