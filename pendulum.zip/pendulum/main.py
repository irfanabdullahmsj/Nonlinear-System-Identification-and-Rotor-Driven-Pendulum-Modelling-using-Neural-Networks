import torch
import torch.nn as nn

from torch.utils.data import DataLoader

from config import *

from load_data import load_dataset

from preprocessing import *

from dataset import TimeSeriesDataset

from neural_ode import NeuralODE

from train_model import train_model

from test_model import test_model

from save_model import save_model

from plotting import plot_results

# ============================================================
# LOAD DATA
# ============================================================

train_data, val_data, test_data = load_dataset()

# ============================================================
# EXTRACT SIGNALS
# ============================================================

train_states, train_u, train_x = extract_signals(
    train_data
)

val_states, val_u, val_x = extract_signals(
    val_data
)

test_states, test_u, test_x = extract_signals(
    test_data
)

# ============================================================
# NORMALIZATION
# ============================================================

(
    train_states,
    val_states,
    test_states,

    train_u,
    val_u,
    test_u,

    train_x,
    val_x,
    test_x,

    state_scaler

) = normalize_data(

    train_states,
    val_states,
    test_states,

    train_u,
    val_u,
    test_u,

    train_x,
    val_x,
    test_x
)

# ============================================================
# DATASETS
# ============================================================

train_dataset = TimeSeriesDataset(

    train_states,

    train_u,

    train_x
)

val_dataset = TimeSeriesDataset(

    val_states,

    val_u,

    val_x
)

test_dataset = TimeSeriesDataset(

    test_states,

    test_u,

    test_x
)

# ============================================================
# DATALOADERS
# ============================================================

train_loader = DataLoader(

    train_dataset,

    batch_size=BATCH_SIZE,

    shuffle=True
)

val_loader = DataLoader(

    val_dataset,

    batch_size=BATCH_SIZE,

    shuffle=False
)

test_loader = DataLoader(

    test_dataset,

    batch_size=BATCH_SIZE,

    shuffle=False
)

# ============================================================
# MODEL
# ============================================================

model = NeuralODE().to(DEVICE)

criterion = nn.MSELoss()

optimizer = torch.optim.Adam(

    model.parameters(),

    lr=LR
)

scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(

    optimizer,

    mode='min',

    factor=0.5,

    patience=10
)

# ============================================================
# TIME VECTOR
# ============================================================

t_span = torch.linspace(

    0,

    DT * (SEQ_LEN - 1),

    SEQ_LEN

).to(DEVICE)

# ============================================================
# TRAIN MODEL
# ============================================================

train_losses, val_losses = train_model(

    model,

    train_loader,

    val_loader,

    optimizer,

    scheduler,

    criterion,

    t_span,

    EPOCHS,

    DEVICE
)

# ============================================================
# SAVE MODEL
# ============================================================

save_model(

    model,

    t_span,

    SEQ_LEN,

    DEVICE
)

# ============================================================
# LOAD BEST MODEL
# ============================================================

best_model = NeuralODE().to(DEVICE)

best_model.load_state_dict(

    torch.load(

        "best_model.pth",

        map_location=DEVICE
    )
)

best_model.eval()

# ============================================================
# TEST MODEL
# ============================================================

predictions, targets = test_model(

    best_model,

    test_loader,

    t_span,

    DEVICE
)

# ============================================================
# INVERSE TRANSFORM
# ============================================================

pred_flat = predictions.reshape(-1, 2)

target_flat = targets.reshape(-1, 2)

pred_inv = state_scaler.inverse_transform(
    pred_flat
)

target_inv = state_scaler.inverse_transform(
    target_flat
)

# ============================================================
# PLOT RESULTS
# ============================================================

plot_results(

    pred_inv,

    target_inv,

    train_losses,

    val_losses
)