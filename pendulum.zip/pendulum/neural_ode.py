import torch.nn as nn

from torchdiffeq import odeint

from ode_func import ODEFunc

# ============================================================
# NEURAL ODE
# ============================================================

class NeuralODE(nn.Module):

    def __init__(self):

        super().__init__()

        self.func = ODEFunc()

    def forward(self, y0, t):

        pred_y = odeint(

            self.func,

            y0,

            t,

            method='rk4'
        )

        return pred_y