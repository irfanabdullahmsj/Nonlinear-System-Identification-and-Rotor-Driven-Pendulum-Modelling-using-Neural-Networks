import torch
import torch.nn as nn

from config import SEQ_LEN
from config import DT

# ============================================================
# ODE FUNCTION
# ============================================================

class ODEFunc(nn.Module):

    def __init__(self):

        super().__init__()

        self.u_sequence = None

        self.x_sequence = None

        self.dt = DT

        self.net = nn.Sequential(

            nn.Linear(4, 64),
            nn.LeakyReLU(),

            nn.Dropout(0.1),

            nn.Linear(64, 64),
            nn.LeakyReLU(),

            nn.Dropout(0.1),

            nn.Linear(64, 64),
            nn.LeakyReLU(),

            nn.Dropout(0.1),

            nn.Linear(64, 2)
        )

    def forward(self, t, y):

        idx = int(

            torch.clamp(

                torch.round(t / self.dt),

                0,

                SEQ_LEN - 1

            ).item()
        )

        u = self.u_sequence[:, idx].unsqueeze(1)

        x = self.x_sequence[:, idx].unsqueeze(1)

        y_u_x = torch.cat(
            [y, u, x],
            dim=1
        )

        return self.net(y_u_x)