import numpy as np
import matplotlib.pyplot as plt

from sklearn.metrics import root_mean_squared_error

# ============================================================
# PLOTTING
# ============================================================

def plot_results(

    pred_inv,

    target_inv,

    train_losses,

    val_losses
):

    # ========================================================
    # TRAINING LOSS
    # ========================================================

    plt.figure(figsize=(8,5))

    plt.plot(
        train_losses,
        label='Train Loss'
    )

    plt.plot(
        val_losses,
        label='Validation Loss'
    )

    plt.xlabel("Epoch")

    plt.ylabel("Loss")

    plt.title("Training vs Validation Loss")

    plt.grid(True)

    plt.legend()

    plt.show()

    # ========================================================
    # RMSE
    # ========================================================

    rmse_phi = root_mean_squared_error(
        target_inv[:, 0],
        pred_inv[:, 0]
    )

    rmse_phid = root_mean_squared_error(
        target_inv[:, 1],
        pred_inv[:, 1]
    )

    print(f"Test RMSE Phi : {rmse_phi:.6f}°")

    print(f"Test RMSE Phid: {rmse_phid:.6f}°/sec")

    # ========================================================
    # PLOTS
    # ========================================================

    true_phi = target_inv[:, 0]

    pred_phi = pred_inv[:, 0]

    true_phid = target_inv[:, 1]

    pred_phid = pred_inv[:, 1]

    plt.figure(figsize=(12, 5))

    # --------------------------------------------------------

    plt.subplot(1, 2, 1)

    plt.plot(
        true_phi,
        label='True Phi'
    )

    plt.plot(
        pred_phi,
        '--',
        label='Pred Phi'
    )

    plt.title("Phi Prediction")

    plt.grid(True)

    plt.legend()

    # --------------------------------------------------------

    plt.subplot(1, 2, 2)

    plt.plot(
        true_phid,
        label='True Phid'
    )

    plt.plot(
        pred_phid,
        '--',
        label='Pred Phid'
    )

    plt.title("Phid Prediction")

    plt.grid(True)

    plt.legend()

    plt.tight_layout()

    plt.show()

    # ========================================================
    # ERROR PLOTS
    # ========================================================

    plt.figure(figsize=(12, 5))

    plt.subplot(1, 2, 1)

    plt.plot(
        pred_phi - true_phi,
        '--',
        label='Phi Error'
    )

    plt.grid(True)

    plt.legend()

    # --------------------------------------------------------

    plt.subplot(1, 2, 2)

    plt.plot(
        pred_phid - true_phid,
        '--',
        label='Phid Error'
    )

    plt.grid(True)

    plt.legend()

    plt.tight_layout()

    plt.show()