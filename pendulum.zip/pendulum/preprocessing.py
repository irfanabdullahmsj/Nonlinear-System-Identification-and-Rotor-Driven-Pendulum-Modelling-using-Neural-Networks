import numpy as np

from sklearn.preprocessing import StandardScaler

# ============================================================
# EXTRACT SIGNALS
# ============================================================

def extract_signals(data):

    phi = data['PA'].squeeze()

    phid = data['PAD'].squeeze()

    u = data['u'].squeeze()

    x = data['x'].squeeze()

    states = np.column_stack(
        (phi, phid)
    )

    return states, u, x

# ============================================================
# NORMALIZATION
# ============================================================

def normalize_data(

    train_states,
    val_states,
    test_states,

    train_u,
    val_u,
    test_u,

    train_x,
    val_x,
    test_x
):

    # ========================================================
    # STATES
    # ========================================================

    state_scaler = StandardScaler()

    train_states_scaled = state_scaler.fit_transform(
        train_states
    )

    val_states_scaled = state_scaler.transform(
        val_states
    )

    test_states_scaled = state_scaler.transform(
        test_states
    )

    # ========================================================
    # CONTROL INPUT
    # ========================================================

    u_scaler = StandardScaler()

    train_u_scaled = u_scaler.fit_transform(
        train_u.reshape(-1, 1)
    ).flatten()

    val_u_scaled = u_scaler.transform(
        val_u.reshape(-1, 1)
    ).flatten()

    test_u_scaled = u_scaler.transform(
        test_u.reshape(-1, 1)
    ).flatten()

    # ========================================================
    # X INPUT
    # ========================================================

    x_scaler = StandardScaler()

    train_x_scaled = x_scaler.fit_transform(
        train_x.reshape(-1, 1)
    ).flatten()

    val_x_scaled = x_scaler.transform(
        val_x.reshape(-1, 1)
    ).flatten()

    test_x_scaled = x_scaler.transform(
        test_x.reshape(-1, 1)
    ).flatten()

    return (

        train_states_scaled,
        val_states_scaled,
        test_states_scaled,

        train_u_scaled,
        val_u_scaled,
        test_u_scaled,

        train_x_scaled,
        val_x_scaled,
        test_x_scaled,

        state_scaler
    )