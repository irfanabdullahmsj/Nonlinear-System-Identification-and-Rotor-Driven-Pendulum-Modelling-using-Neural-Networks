import torch

# ============================================================
# SAVE MODEL
# ============================================================

def save_model(

    model,

    t_span,

    seq_len,

    device
):

    torch.save(
        model.state_dict(),
        "best_model.pth"
    )

    dummy_y0 = torch.randn(
        1,
        2
    ).to(device)

    dummy_u_seq = torch.randn(
        1,
        seq_len
    ).to(device)

    dummy_x_seq = torch.randn(
        1,
        seq_len
    ).to(device)

    model.func.u_sequence = dummy_u_seq

    model.func.x_sequence = dummy_x_seq

    torch.onnx.export(

        model,

        (dummy_y0, t_span),

        "best_model.onnx",

        export_params=True,

        opset_version=11,

        do_constant_folding=True,

        input_names=[
            'initial_state',
            'time_vector'
        ],

        output_names=[
            'predicted_states'
        ],

        dynamic_axes={

            'initial_state': {
                0: 'batch_size'
            },

            'predicted_states': {
                1: 'batch_size'
            }
        }
    )

    print("ONNX model exported!")