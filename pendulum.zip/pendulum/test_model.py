import numpy as np
import torch

# ============================================================
# TESTING
# ============================================================

def test_model(

    model,

    test_loader,

    t_span,

    device
):

    predictions = []

    targets = []

    model.eval()

    with torch.no_grad():

        for x0, target, u_seq, x_seq in test_loader:

            x0 = x0.to(device)

            model.func.u_sequence = (
                u_seq.to(device)
            )

            model.func.x_sequence = (
                x_seq.to(device)
            )

            pred = model(
                x0,
                t_span
            )

            pred = pred.permute(1, 0, 2)

            predictions.append(
                pred.cpu().numpy()
            )

            targets.append(
                target.numpy()
            )

    predictions = np.concatenate(
        predictions,
        axis=0
    )

    targets = np.concatenate(
        targets,
        axis=0
    )

    return predictions, targets