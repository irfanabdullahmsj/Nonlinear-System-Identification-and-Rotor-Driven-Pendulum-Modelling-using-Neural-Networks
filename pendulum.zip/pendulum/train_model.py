import torch
import numpy as np
import time

from config import EARLY_STOP

# ============================================================
# TRAINING
# ============================================================

def train_model(

    model,

    train_loader,

    val_loader,

    optimizer,

    scheduler,

    criterion,

    t_span,

    epochs,

    device
):

    best_val = np.inf

    train_losses = []

    val_losses = []

    start_time = time.time()

    for epoch in range(epochs):

        model.train()

        total_train_loss = 0

        for x0, target, u_seq, x_seq in train_loader:

            x0 = x0.to(device)

            target = target.to(device)

            model.func.u_sequence = (
                u_seq.to(device)
            )

            model.func.x_sequence = (
                x_seq.to(device)
            )

            optimizer.zero_grad()

            pred = model(
                x0,
                t_span
            )

            pred = pred.permute(1, 0, 2)

            loss = criterion(
                pred,
                target
            )

            loss.backward()

            torch.nn.utils.clip_grad_norm_(
                model.parameters(),
                max_norm=1.0
            )

            optimizer.step()

            total_train_loss += loss.item()

        avg_train_loss = (
            total_train_loss / len(train_loader)
        )

        # ====================================================
        # VALIDATION
        # ====================================================

        model.eval()

        total_val_loss = 0

        with torch.no_grad():

            for x0, target, u_seq, x_seq in val_loader:

                x0 = x0.to(device)

                target = target.to(device)

                model.func.u_sequence = (
                    u_seq.to(device)
                )

                model.func.x_sequence = (
                    x_seq.to(device)
                )

                pred = model(
                    x0,
                    t_span
                )

                pred = pred.permute(1, 0, 2)

                loss = criterion(
                    pred,
                    target
                )

                total_val_loss += loss.item()

        avg_val_loss = (
            total_val_loss / len(val_loader)
        )

        scheduler.step(avg_val_loss)

        train_losses.append(avg_train_loss)

        val_losses.append(avg_val_loss)

        print(

            f"Epoch {epoch+1}/{epochs} | "

            f"Train Loss: "
            f"{avg_train_loss:.6f} | "

            f"Val Loss: "
            f"{avg_val_loss:.6f}"
        )

        # ====================================================
        # SAVE BEST MODEL
        # ====================================================

        if avg_val_loss < best_val:

            best_val = avg_val_loss

            torch.save(
                model.state_dict(),
                "best_model.pth"
            )

            print(
                f"Best model saved! "
                f"Val Loss: {best_val:.6f}"
            )

        # ====================================================
        # EARLY STOP
        # ====================================================

        if avg_val_loss < EARLY_STOP:

            print(
                f"Breaking early at epoch {epoch}"
            )

            break

    total_time = time.time() - start_time

    print(
        f"\nTotal Training Time: "
        f"{total_time/60:.2f} minutes"
    )

    return train_losses, val_losses